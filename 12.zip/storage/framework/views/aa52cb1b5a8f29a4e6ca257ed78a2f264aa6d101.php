[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\portafolio\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>